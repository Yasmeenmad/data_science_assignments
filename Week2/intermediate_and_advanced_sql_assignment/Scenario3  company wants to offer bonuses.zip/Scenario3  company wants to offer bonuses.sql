#The Average salaries for males and females in general
# Note: we have used this query in the first scenario
SELECT 
    e.gender, AVG(s.salary)
FROM
    employees e
        JOIN
    salaries s ON e.emp_no = s.emp_no
GROUP BY gender;


# Years of Experience and salary for each employee in the last department they worked in
SELECT e.emp_no, concat(e.first_name, ' ', e.last_name) employee_name, e.hire_date,
       s.to_date, round((s.to_date-e.hire_date)/10000) service_years, s.salary
FROM
	salaries s
		JOIN
	employees e ON s.emp_no = e.emp_no
		JOIN
    dept_emp de ON e.emp_no = de.emp_no
		JOIN
    departments d ON de.dept_no = d.dept_no
WHERE s.to_date >= (SELECT MAX(to_date) FROM salaries s WHERE s.emp_no = e.emp_no);


# Total salaries of employees during the past year
SELECT SUM(salary) FROM salaries;

# Employees whose contracts will soon expire within the next two months and their salaries
SELECT e.emp_no, concat(e.first_name, ' ', e.last_name) employee_name, s.to_date, s.salary
FROM 
	employees e
		JOIN
	salaries s ON e.emp_no = s.emp_no
WHERE s.to_date BETWEEN '2001-01-01' AND '2001-12-31'
ORDER BY s.to_date;