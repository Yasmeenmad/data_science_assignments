# The number of male and female employees in the company
SELECT gender, COUNT(gender)
FROM employees
GROUP BY gender;


# The number of females and males who have been employed during the past five years
SELECT YEAR(hire_date) year, gender, COUNT(gender)
FROM employees
WHERE hire_date BETWEEN '1996-12-31' AND '2000-12-31'
GROUP BY year, gender
ORDER BY year desc;


# The number of females and males who have been employed during the past five years in each department
SELECT YEAR(e.hire_date) year, d.dept_name, e.gender, count(e.gender)
FROM
	salaries s
		JOIN
	employees e ON s.emp_no = e.emp_no
		JOIN
    dept_emp de ON e.emp_no = de.emp_no
		JOIN
    departments d ON de.dept_no = d.dept_no
WHERE e.hire_date BETWEEN '1996-12-31' AND '2000-12-31'
GROUP BY year, d.dept_name, e.gender
ORDER BY year desc;


# The number of male and female employees in each department
SELECT d.dept_name, e.gender, COUNT(e.gender)
FROM
	employees e 
        JOIN
    dept_emp de ON e.emp_no = de.emp_no
        JOIN
    departments d ON de.dept_no = d.dept_no
GROUP BY d.dept_name, e.gender;


# The average salary for male and female in each departments
SELECT d.dept_name,e.gender,
    AVG(s.salary) AS average_salary
FROM
	salaries s
		JOIN
	employees e ON s.emp_no = e.emp_no
		JOIN
    dept_emp de ON e.emp_no = de.emp_no
		JOIN
    departments d ON de.dept_no = d.dept_no
GROUP BY d.dept_name, e.gender;


#The Average salaries for males and females in general
SELECT 
    e.gender, AVG(s.salary)
FROM
    employees e
        JOIN
    salaries s ON e.emp_no = s.emp_no
GROUP BY gender;