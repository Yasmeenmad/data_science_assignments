#Query 2: Try to develop a strategy to reduce cost of all contracts expiring within 
# a year instead of downsizing departments.

SELECT CONCAT(e.first_name, ' ',e.last_name) as Emp_name,s.* 
FROM salaries s, employees e 
WHERE e.emp_no = s.emp_no and (s.to_date) >= '2001-01-01' 
and (s.to_date) <= '2001-12-31' and s.emp_no 
NOT IN (SELECT s.emp_no 
FROM salaries s 
WHERE (s.to_date) > '2001-12-31') and s.to_date = (SELECT MAX(to_date) 
FROM salaries WHERE emp_no = s.emp_no)