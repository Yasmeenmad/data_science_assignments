# Query1-1: Find out the total amount of salaries paid to each department 
SELECT d.dept_name,SUM(s.salary) 
FROM salaries s, dept_emp de, departments d 
WHERE s.emp_no = de.emp_no and de.dept_no = d.dept_no and s.to_date = (SELECT MAX(to_date) FROM salaries 
WHERE emp_no = s.emp_no) 
GROUP BY d.dept_name;
 
 # Query1-2:The average of each department 
SELECT d.dept_name,Avg(s.salary) 
FROM salaries s, dept_emp de, departments d 
WHERE s.emp_no = de.emp_no and de.dept_no = d.dept_no and s.to_date = (SELECT MAX(to_date) FROM salaries 
WHERE emp_no = s.emp_no) 
GROUP BY d.dept_name;
 
  # Query1-3:assess whether any service/contract is overpaid by comparing it to the salaries paid to 
  # the employees in the same department 
 DROP TABLE IF EXISTS Depart_Avg;
CREATE TEMPORARY TABLE Depart_Avg (dept_no varchar(200),dep_avg decimal(65,2));
INSERT INTO Depart_Avg

SELECT DISTINCT(d.dept_no),ROUND(AVG(s.salary),2) as dep_avg  FROM salaries s, dept_emp de, departments d 
WHERE s.emp_no = de.emp_no and de.dept_no = d.dept_no and s.to_date = (SELECT MAX(to_date) FROM salaries 
WHERE emp_no = s.emp_no) 
GROUP BY d.dept_name;


SELECT d.dept_name,CONCAT(e.first_name ,' ', e.last_name) as Emp_Name,e.emp_no,s.salary,dv.dep_avg 
FROM salaries s, dept_emp de, departments d, employees e, Depart_Avg dv 
WHERE s.emp_no = de.emp_no and de.dept_no = d.dept_no and s.emp_no = e.emp_no and dv.dept_no = d.dept_no and s.salary > dv.dep_avg AND 
s.to_date = (SELECT MAX(to_date) FROM salaries WHERE emp_no = s.emp_no)
GROUP BY d.dept_name, Emp_Name,e.emp_no,s.salary,dv.dep_avg;