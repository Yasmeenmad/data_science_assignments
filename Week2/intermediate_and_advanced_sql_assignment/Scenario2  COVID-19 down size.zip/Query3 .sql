#Query3: If reducing salaries for the new contracts does not work, 
#then find a strategy for downsizing the departments. 
#This might include pushing employees to early retirements. 
#Make sure not to reduce any department more than 50% of its staff.

# Here we find the information of the all department, and employees 
SELECT d.dept_name,d.dept_no, CONCAT(e.first_name, ' ',e.last_name) as Emp_name , s.emp_no,s.salary,s.to_date
FROM salaries s, dept_emp de, employees e, departments d 
WHERE s.emp_no = e.emp_no and de.emp_no = s.emp_no and de.dept_no = d.dept_no and s.to_date = (SELECT MAX(to_date) 
FROM salaries 
WHERE emp_no = s.emp_no)  ORDER BY d.dept_name ASC;