use mydb;
show tables;

# Inserting the values to the Suppliers table
insert into Suppliers (Item_Name, Item_Price, Quantity)
values ('GREEN soap', 13, 5);
insert into Suppliers (Item_Name, Item_Price, Quantity)
values ('X sterilizer', 15, 15);
insert into Suppliers (Item_Name, Item_Price, Quantity)
values ('SHINE polished', 20, 10);
insert into Suppliers (Item_Name, Item_Price, Quantity)
values ('Toyota Car', 100000, 1);
# To Check if the values are inserted
select * from Suppliers;

# Inserting the values to the Services table
insert into Services (Service_Name, Service_Price)
values ('Regular Washing', '100 SAR');
insert into Services (Service_Name, Service_Price)
values ('Steam Washing', '150 SAR');
insert into Services (Service_Name, Service_Price)
values ('Inside cleaning', '70 SAR');
insert into Services (Service_Name, Service_Price)
values ('Sterilization',  '50 SAR');
# To Check if the values are inserted
select * from Services;

# Inserting the values to the Customers table
insert into Customers (F_name, L_name, Phone_Number, Email)
values ('Ali','Ahmed','0543567936','Ali_Ahmed@gmail.com');
insert into Customers (F_name, L_name, Phone_Number, Email)
values ('Khaled','Turki','0543567954','Khaled_Turki@gmail.com');
insert into Customers (F_name, L_name, Phone_Number, Email)
values ('Mohammed','Saleh','0543567988','Mohammed_Saleh@gmail.com');
# To Check if the values are inserted
select * from Customers;

# Inserting the values to the Equipments table
insert into Equipments (Type, Suppliers_ID)
values ('Cleaning Equipments',1);
insert into Equipments (Type, Suppliers_ID)
values ('Cleaning Equipments',2);
insert into Equipments (Type, Suppliers_ID)
values ('Car Equipments',4);
# To Check if the values are inserted
select * from Equipments;

# Inserting the values to the Employees table
insert into Employees (F_Name, L_Name, Salary, Equipments_ID)
values ('Naif','Tareg',5000,1);
insert into Employees (F_Name, L_Name, Salary, Equipments_ID)
values ('Asem','Ahmed',5000,3);
insert into Employees (F_Name, L_Name, Salary, Equipments_ID)
values ('Ali','salah',5000,2);
# To Check if the values are inserted
select * from Employees;

# Inserting the values to the Orders table
insert into Orders (Order_Date, Order_Price, Services_ID, Employees_ID, Customers_ID)
values ('2019-8-4',100,1,2,1);
insert into Orders (Order_Date, Order_Price, Services_ID, Employees_ID, Customers_ID)
values ('2016-7-15',150,2,3,3);
insert into Orders (Order_Date, Order_Price, Services_ID, Employees_ID, Customers_ID)
values ('2018-3-3',50,4,1,2);
# To Check if the values are inserted
select * from Orders;
