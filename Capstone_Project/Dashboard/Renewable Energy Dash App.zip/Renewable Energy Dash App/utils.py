import dash_html_components as html
import dash_core_components as dcc
import json
from urllib.request import urlopen
import base64

image_filename = 'vision.png'
encoded_image = base64.b64encode(open(image_filename, 'rb').read()).decode('ascii')


def Header(app):
    return html.Div([get_header(app), get_space(app), html.Br([]), get_menu()])

def Bottom(app):
    return html.Div([get_bottom(app), get_space(app), html.Br([])])


def get_header(app):
    header = html.Div([
            html.H5("Forecasting Weather in", style = {'textAlign': 'center', "padding-top": "45px"}),
            html.H5("Saudi Arabia for", style = {'textAlign': 'center'}),
            html.H5("Renewable Energy Applications", style = {'textAlign': 'center'}),
            ], className="twelve columns main-title", style = {"height": "200px", "padding-left": "30px"}
    )
    return header

def get_space(app):
    space = html.Div([
        html.H6(" ")
        ], className="twelve columns", style = {"height": "10px"},
    )
    
    return space

def get_bottom(app):
    header = html.Div([
                html.Div([
                    html.Img(src='data:image/png;base64,{}'.format(encoded_image), style = {'width': '180px', 'height':'150px', "padding-top": "40px"})
                    
                ], style = {'textAlign': 'center'})
            ], className="twelve columns bottom-title", style = {"height": "200px", "padding-bottom":"60px"}
    )
    return header

def get_menu():
    menu = html.Div(
        [
            dcc.Link(
                "Overview",
                href="/dash-financial-report/overview",
                className="tab first",
            ),
            dcc.Link(
                "Dataset",
                href="/dash-financial-report/dataset",
                className="tab",
            ),
            dcc.Link(
                "Weather Conditions", 
                href="/dash-financial-report/weather", 
                className="tab"
            ),
            
            dcc.Link(
                "Regional Trends", 
                href="/dash-financial-report/regional-trends", 
                className="tab"
            ),
            
            dcc.Link(
                "Cities Ranking",
                href="/dash-financial-report/cities-ranking",
                className="tab",
            ),
            
            dcc.Link(
                "Statistic Time Series",
                href="/dash-financial-report/stat-time-series",
                className="tab",
            ),
            
        ],
        className="row all-tabs", style = {"padding-top": "60px"}
    )
    return menu


def make_dash_table(df):
    """ Return a dash definition of an HTML table for a Pandas dataframe """
    table = []
    columns = df.columns.values.tolist()
    html_row = []
    for i in range(len(columns)):
        html_row.append(html.Td([columns[i]]))
    table.append(html.Tr(html_row))
    
    for index, row in df.iterrows():
        html_row = []
        for i in range(len(row)):
            html_row.append(html.Td([row[i]]))
        table.append(html.Tr(html_row))
        
    return table
