# -*- coding: utf-8 -*-
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from pages import (
    overview,
    dataset,
    weather,
    regional_trends,
    cities_ranking,
    stat_time_series,
)

app = dash.Dash(
    __name__, meta_tags=[{"name": "viewport", "content": "width=device-width"}],
)
app.title = "Forecast"
server = app.server

# Describe the layout/ UI of the app
app.layout = html.Div(
    [dcc.Location(id="url", refresh=False), html.Div(id="page-content")]
)

# Update page
@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def display_page(pathname):
    if pathname == "/dash-financial-report/dataset":
        return dataset.create_layout(app)
    elif pathname == "/dash-financial-report/weather":
        return weather.create_layout(app)
    elif pathname == "/dash-financial-report/regional-trends":
        return regional_trends.create_layout(app)
    elif pathname == "/dash-financial-report/cities-ranking":
        return cities_ranking.create_layout(app)
    elif pathname == "/dash-financial-report/stat-time-series":
        return stat_time_series.create_layout(app)
    elif pathname == "/dash-financial-report/full-view":
        return (
            overview.create_layout(app),
            dataset.create_layout(app),
            weather.create_layout(app),
            regional_trends.create_layout(app),
            cities_ranking.create_layout(app),
            stat_time_series.create_layout(app),
        )
    else:
        return overview.create_layout(app)


if __name__ == "__main__":
    app.run_server(debug=True)
