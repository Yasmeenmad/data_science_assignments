import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
from utils import Header, make_dash_table, Bottom
import pandas as pd
import pathlib
import dash_table

import base64

image_filename = 'vision.png'
encoded_image = base64.b64encode(open(image_filename, 'rb').read()).decode('ascii')

# get relative data folder
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../data").resolve()


df = pd.read_csv(DATA_PATH.joinpath("Capstone_Dataset_Final.csv"))

df_5_rows = df.head(5)

# any unnamed columns will be omitted
for column in df_5_rows.columns.values.tolist():
    if 'Unnamed:' in column:
        df_5_rows = df_5_rows.drop([column], axis = 1)


def create_layout(app):
    return html.Div(
        [
            Header(app),
            
            # page 2
            html.Div(
                [
                    # Row
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        ["About the Data"], className="subtitle padded"
                                    ),
                                    
                                    html.P(
                                        "Through this dataset, we provide hourly historical weather data for all Saudi Arabia cities from 2017 to 2019. Included a date for which you would like to see weather history such as temperature, wind, humidity, barometer, and visibility."
                                    ),
                                    
                                    
                                    html.P(
                                        "Data Source: https://www.kaggle.com/esraamadi/saudi-arabia-weather-history"
                                    ),
                               
                                    
                                    html.H6(
                                        ["Data Table Snippet"], className="subtitle padded"
                                    ),
                                    
                                    
                                    dash_table.DataTable(
                                        data=df_5_rows.to_dict('records'),
                                        columns=[{'id': c, 'name': c} for c in df_5_rows.columns], 
                                        style_table = {'overflowX': 'scroll'}
                                    ),
                                    
                                    
                                    html.H6(
                                        ["Variable Definitions"], className="subtitle padded"
                                    ),
                                    
                                    html.P(
                                        "city: KSA city name"
                                    ),
                                    
                                    html.P(
                                        "date: recorded date"
                                    ),
                                    
                                    html.P(
                                        "time: recorded time"
                                    ),
                                    
                                    html.P(
                                        "year: recorded date - year month: recorded date - month day: recorded date - day"
                                    ),
                                    
                                    html.P(
                                        "hour: recorded time - hour"
                                    
                                    ),
                                    
                                    html.P(
                                        "minute: recorded time - minute"
                                    ),
                                    
                                    html.P(
                                        "weather: recorded weather description (clear - sunny - ....) temp: recorded temperature (°C)"
                                    ),
                                    
                                    html.P(
                                        "wind: recorded wind speed (km/h)"
                                    ),
                                    
                                    html.P(
                                        "humidity: recorded quality of being humid (%)"
                                    ),
                                    
                                    html.P(
                                        "barometer: recorded atmospheric pressure (mb)"
                                    ),
                                    
                                    html.P(
                                        "visibility: recorded how much be able to see or be seen (km)"
                                    ),
                                
                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row ",
                        style={"margin-bottom": "0px"}
                    ),
                    
                    
                    
                ],
                className="sub_page",
            ),
            
            html.Div([
                html.Div([
                    html.Img(src='data:image/png;base64,{}'.format(encoded_image), style = {'width': '180px', 'height':'150px', "padding-top": "5px"})
                    
                ], style = {'textAlign': 'center'})
            ], className="twelve columns bottom-title", style = {"height": "160px", "padding-bottom":"60px"}
    )
        ],
        className="datasetpage",
    )
