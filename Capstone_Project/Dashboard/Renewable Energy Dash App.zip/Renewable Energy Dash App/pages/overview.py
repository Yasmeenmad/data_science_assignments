import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go

from utils import Header, make_dash_table, Bottom

import pandas as pd
import pathlib

# get relative data folder
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../data").resolve()




def create_layout(app):
    return html.Div(
        [
            Header(app),
            
            # page 2
            html.Div(
                [
                    # Row
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        ["Overview"], className="subtitle padded"
                                    ),
                                    
                                    html.P(
                                        "Saudi Arabia plans to harness 9.5 GW of renewable energy sources according to 2030 vision. Solar PV and wind farms constitute a major part of this investment. Hence, this huge investment in solar PV and wind farms projects requires an accurate assessment and analysis to select the appropriate sites. The main objective of this study is to answer the question, Where to invest for solar and wind energy?", style = {"font-size": "13px"}
                                    ),
                                    
                                    
                                    
                                
                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row ",
                        style={"margin-bottom": "0px"}
                    ),
                    
                    
                    
                ],
                className="sub_page",
            ),
            
            html.Div([Bottom(app)]),
        ],
        className="overviewpage",
    )
