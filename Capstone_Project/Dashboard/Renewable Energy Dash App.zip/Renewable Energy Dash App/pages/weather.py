# Importing required libraries
import sklearn
import numpy as np
import pandas as pd
import plotly.express as px
from functools import reduce

import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go

from utils import Header, make_dash_table, Bottom
import pandas as pd
import pathlib

# get relative data folder
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../data").resolve()


df = pd.read_csv(DATA_PATH.joinpath("Capstone_Dataset_Final.csv"))


bar_colors = [
                # '#151117', 
               '#2d2d42', 
            #   '#433d46',
                '#0D0A48',
               '#2d2a46', 
               '#45465f', 
              # '#565865',  
             #  '#565865', 
               '#868698',
             #  '#857975', 
               '#a09790', 
             #  '#ccae8d', 
               '#ba8637', 
               '#ac6c24', 
              '#f6c777' ]

# a. Temperature Degree vs Humidity Percentage per Season
fig_a = px.scatter(df, 
                 x ='temp', 
                 y='humidity', 
                 color='season', 
                 width=550, 
                 height=250, 
)

fig_a.update_layout(
                    margin={"r": 5, "t": 10, "b": 10, "l": 5})

fig_b = px.histogram(df, 
                   x="weather_category", 
                   color="year",
                   width=550, 
                   height=250, )

fig_b.update_layout(
                    margin={"r": 40, "t": 10, "b": 10, "l": 40})



def create_layout(app):
    # Page layouts
    return html.Div(
        [
            html.Div([Header(app)]),
            
            # page 1
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [

                                    html.P(
                                        "The following two plots examines and analyses the weather data (temperature, humidity, rain, wind) in Saudi Arabia in each season. Also, the figure shows mostly the weather categorized “Clear” of the entire year. Saudi Arabia mostly has very hot weather condition, where the temperature approaching 48 ◦C in summer between May and September. Dry with little rain season in most of Saudi Arabia regions with humid weather for the average of 60% near the coastal regions. It aims to help a decision-makers to address the demand of generating the renewable energy and the production of alternative electricity. The different environmental factors can significantly affect on the efficacy of the renewable energy production.", style = {"font-size": "13px", "textAlign": "center"}
                                    ),
                                    

                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row ",
                        style={"margin-bottom": "0px"}
                    ),
                    # Row 2
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        'Weather Category Count in Each Year',
                                        className="subtitle padded", style = {"textAlign":"center"}
                                    ),
                                    
                                    html.Div([
                                    
                                        dcc.Graph(
                                            id="graph-2",
                                            figure= fig_b,

                                        ),
                                    ], style = {'padding-left':'110px'})
                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row ",
                        style={"margin-top": "35px"}
                    ),
                    
                    
                ],
                className="sub_page",
            ),
            
            html.Div([Bottom(app)]),
            
        ], className = "weatherpage",
    )
