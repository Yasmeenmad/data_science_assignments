# Importing required libraries
import sklearn
import numpy as np
import pandas as pd
import plotly.express as px
from functools import reduce

import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go

from utils import Header, make_dash_table, Bottom
import pandas as pd
import pathlib

# get relative data folder
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../data").resolve()



df = pd.read_csv(DATA_PATH.joinpath("Capstone_Dataset_Final.csv"))




bar_colors = [
                # '#151117', 
               '#2d2d42', 
            #   '#433d46',
                '#0D0A48',
               '#2d2a46', 
               '#45465f', 
              # '#565865',  
             #  '#565865', 
               '#868698',
             #  '#857975', 
               '#a09790', 
             #  '#ccae8d', 
               '#ba8637', 
               '#ac6c24', 
              '#f6c777' ]


# FIGURE A
# Find the average temperature of every month for each city 

data_a = df.groupby(['city','month'])['temp'].mean()

fig_a = px.line(data_a, 
              x = data_a.index.get_level_values('month'), 
              y = data_a.values,
              color=data_a.index.get_level_values('city'),
             labels=dict(x="Month", y="Average Temperature (°C)", color="City Name:"))
fig_a.update_layout(
                    margin={"r": 5, "t": 10, "b": 10, "l": 5})


# FIGURE B

# Find the Average Temperatures In Each Season For Saudi Arabia Cities
data_b = df.groupby(['city', 'season'])['temp'].mean()

fig_b = px.line(data_b, 
              x = data_b.index.get_level_values('city'), 
              y = data_b.values,
              color=data_b.index.get_level_values('season'),
             labels=dict(x="City", y="Average Temperature (°C)", color="Season:"))

fig_b.update_layout(
                    margin={"r": 5, "t": 10, "b": 10, "l": 5})

# FIGURE C

# Find The Average Wind Speed Through 24 Hours For Each Season
data_c = df.groupby(['season','hour'])['wind'].mean()

fig_c = px.line(data_c, 
              x = data_c.index.get_level_values('hour'), 
              y = data_c.values,
              color=data_c.index.get_level_values('season'),
             labels=dict(x="Hours", y="Average Wind Speed (km/h)", color="Season:"))
fig_c.update_layout(
                    margin={"r": 5, "t": 10, "b": 10, "l": 5})

# FIGURE D

# Find Monthly Average Wind Speed For Saudi Arabia Cities
data_d = df.groupby(['city','month'])['wind'].mean()

fig_d = px.line(data_d, 
              x = data_d.index.get_level_values('month'), 
              y = data_d.values,
              color=data_d.index.get_level_values('city'),
             labels=dict(x="Month", y="Average Wind Speed (km/h)", color="City Name:"))

fig_d.update_layout(
                    margin={"r": 5, "t": 10, "b": 10, "l": 5})






def create_layout(app):
    # Page layouts
    return html.Div(
        [
            html.Div([Header(app)]),
            
            # page 1
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [

                                    html.P("The two-line charts represent the Temperatures degree and Wind percentage for 13 Saudi Arabia Region over three years. The long hours of sunrises in the Gulf region in general and Saudi Arabia are between a maximum and minimum of 9.4 and 7.4 h/day. The long hours of sunrises are significant factors to rise the renewable energy production. The Cities who have the high temperature degree above 50 °C and high wind percentage more than 23 km/h can be considered one of the factors to be the most effective locations to install the PV panel and wind Turbine. ", style = {"font-size": "13px", "textAlign": "center"}
                                    ),
                                    

                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row ",
                        style={"margin-bottom": "35px"}
                    ),
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "Monthly Average Temperatures For Saudi Arabia Cities",
                                        className="subtitle padded", style = {"textAlign":"center"}
                                    ),
                                    
                                    html.Div([
                                        dcc.Graph(
                                            id="graph-1",
                                            figure=fig_a,
                                            style = {"height": "255px"},
                                        ) 
                                    ], style = {'padding-left':'60px'})
                          
                                ],
                                className="twelve columns", style = {"textAlign":"center"},
                            ),
                        ],
                        className="row",
                        style={"margin-bottom": "15px"},
                    ),
                    # Row 2
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "Average Temperatures In Each Season For Saudi Arabia Cities",
                                        className="subtitle padded", style = {"textAlign":"center"}
                                    ),
                                    html.Div([
                                        dcc.Graph(
                                            id="graph-2",
                                            figure=fig_b,
                                            style = {"height": "255px"},
                                        ) 
                                    ], style = {'padding-left':'60px'})
                                ],
                                className="twelve columns", style = {"textAlign":"center"},
                            ),
                            
                        ],
                        className="row ",
                        style={"margin-top": "15px"}
                    ),
                    
                    # Row 3
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "The Average Wind Speed Through 24 Hours For Each Season",
                                        className="subtitle padded", style = {"textAlign":"center"}
                                    ),
                                    html.Div([
                                        dcc.Graph(
                                            id="graph-3",
                                            figure=fig_c,
                                            style = {"height": "255px"},
                                        ) 
                                    ], style = {'padding-left':'60px'})
                                ],
                                className="twelve columns", style = {"textAlign":"center"},
                            ),
                            
                        ],
                        className="row ",
                        style={"margin-top": "15px"}
                    ),
                    
                    # Row 4
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "Monthly Average Wind Speed For Saudi Arabia Cities",
                                        className="subtitle padded", style = {"textAlign":"center"}
                                    ),
                                    html.Div([
                                        dcc.Graph(
                                            id="graph-4",
                                            figure=fig_d,
                                            style = {"height": "255px"},
                                        ) 
                                    ], style = {'padding-left':'60px'})
                                ],
                                className="twelve columns", style = {"textAlign":"center"},
                            ),
                            
                        ],
                        className="row ",
                        style={"margin-top": "15px"}
                    ),
                    
                    
                ],
                className="sub_page",
            ),
            
            html.Div([Bottom(app)]),
            
        ], className = "regionalpage",
    )
