import setuptools
# Loads your README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pkg_yasmeenali", 
    version="0.0.3",
    author="Yasmeen Aldossary",
    author_email="yasmeenmad@gmail.com",
    description="A package to perform some operations on lists like: maximum item, minimum item, squared maximum, list lenght, positive sum, negative sum, positive list and sumation of two lists", 
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Yasmeenmad",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ], 
    packages=setuptools.find_packages(), 
    python_requires=">=3.7",
)
