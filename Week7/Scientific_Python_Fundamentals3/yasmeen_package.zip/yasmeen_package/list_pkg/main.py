class ListClass(object):
    # initialize the class correctly
    def __init__(self, mylist):
        self.mylist = mylist
    
    
    
    # return the max value in the list
    def return_max(self):
        # lets put the first number in the list as the largest
        max = self.mylist[0]
    
        # for-loop to find the maximum number
        for item in self.mylist:
            if item > max :
                 max = item
        return max
    
    
    
    # return the minimum value in the list
    def return_min(self):
        # lets put the first number in the list as the smallest
        min = self.mylist[0]
        
        # for-loop to find the minimum value
        for item in self.mylist:
            if item < min :
                min = item
        return min
    
    
    
    # return the max value squared
    def return_max_squared(self):
        # lets put the first number in the list as the largest
        max = self.mylist[0]
    
        # for-loop to find the maximum number
        for item in self.mylist:
            if item > max :
                 max = item
        # return the max value squared
        return (max**2)
    
    
    
    # return the length of the list
    def return_length(self):
        return len(self.mylist)

    
    
    # return the sum of all positive numbers only in the list
    def return_positive_sum(self):
        # set the sum as 0
        sum = 0
        
        # for-loop to find the positive numbers in a list then return the sum
        for item in self.mylist:
            if item > 0:
                sum += item
        return sum
    
    
    
    
    # return the count of all negative numbers in the list
    def return_negative_count(self):
        count = 0
        for item in self.mylist:
            if item < 0:
                count += 1
        return count

    
    # return the all the values in the list as positive values
    def return_positive_list(self):
        # empty list
        new_list = []
        
        # for-loop to find the negative values and replace them with positive values in a list
        for item in self.mylist:
            if item < 0:
                item = - item
            new_list.append(item)
        return new_list
    
    # return the sum of two lists with the same length
    def return_sum_two_lists(self,list2):
        self.list2 = list2
        # empty list to put the sum of two lists
        sum_list = []
        
        # for-loop to loop in the two lists 
        for (item1, item2) in zip(self.mylist, list2):
            
            # check if the lengths of the two lists are equals or not
            # if the lengths equals then add the the first element in list1
            # with the first element in list2 and so on
            if len(self.mylist) != len(list2):
                return "You must enter lists with the same length"
            else:
                sum_list.append(item1 + item2)
        return sum_list

if __name__ == "__main__":
    ListClass()